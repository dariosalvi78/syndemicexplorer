# Copyright (C) 2020 University of Oxford
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#
# SCB
# https://www.scb.se/
#

import pandas as pd
import json
import os

SOURCE = 'SWE_SCB'
BASE_PATH = os.path.dirname(os.path.realpath(__file__))

class MalmoDemographicsFetcher():
    '''Creates SQL inserts for the surveys table with demographics data.'''
    
    ADM_AREA_3_CODES = {
        'Centrum': 'SWE.13.19.1_1',
        'Fosie': 'SWE.13.19.2_1',
        'Husie': 'SWE.13.19.3_1',
        'Hyllie': 'SWE.13.19.4_1',
        'Kirseberg': 'SWE.13.19.5_1',
        'Limhamn-Bunkeflo': 'SWE.13.19.6_1',
        'Oxie': 'SWE.13.19.7_1',
        'Rosengård': 'SWE.13.19.8_1',
        'Södra Innerstaden': 'SWE.13.19.9_1',
        'Västra Innerstaden': 'SWE.13.19.10_1'
    }

    YEARS = ['2018', '2019', '2020']

    def merge_dict(self, dictionary, table):
        '''Merges dictionaries with keys in common into one nested dictionary.'''
        dict_year = list(dictionary.values())[0]
        dict_district = list(dictionary.values())[1]
        dict_indicator = list(dictionary.values())[2]

        if table == 'number and average':
            dict_number_of_people = list(dictionary.values())[3]
            dict_average_income = list(dictionary.values())[4]
        elif table == 'overcrowdedness':
            dict_not_overcrowded = list(dictionary.values())[3]
            dict_overcrowded = list(dictionary.values())[4]
        elif table == 'single value':
            dict_number = list(dictionary.values())[3]

        merged_dicts = {}

        for key in dict_year:
            new_dict = {}
            new_dict['year'] = str(dict_year[key])
            new_dict['district'] = dict_district[key]
            new_dict['indicator'] = dict_indicator[key]

            if table == 'number and average':
                new_dict['number of people'] = dict_number_of_people[key]
                new_dict['average income'] = dict_average_income[key]
            elif table == 'overcrowdedness':
                new_dict['not overcrowded'] = dict_not_overcrowded[key]
                new_dict['overcrowded'] = dict_overcrowded[key]
            elif table == 'single value':
                new_dict['number'] = dict_number[key]
            
            merged_dicts[key] = new_dict
        
        return merged_dicts


    def fetch(self, file, table):
        '''Reads the data from the Excel file and merges to a nested dictionary.'''
        df = pd.read_excel(os.path.join(BASE_PATH, file))

        nested_dict = df.to_dict()
        merged_dict = self.merge_dict(nested_dict, table)

        return merged_dict


    
    def run(self):
        '''Iterates through the years and stadsdelar to create SQL inserts from the fetched data.'''
        sql_insert = ''

        demographics = self.fetch('swe_scb_malmo_demographics.xlsx', 'single value')
        foreign_background = self.fetch('swe_scb_malmo_foreign-background.xlsx', 'single value')
        educational_level = self.fetch('swe_scb_malmo_educational-level.xlsx', 'single value')
        total_income = self.fetch('swe_scb_malmo_total-earned-and-capital-income.xlsx', 'number and average')
        disposable_income = self.fetch('swe_scb_malmo_disposable-income.xlsx', 'number and average')
        overcrowdedness = self.fetch('swe_scb_malmo_overcrowdedness.xlsx', 'overcrowdedness')

        data_dicts = [
            demographics, 
            foreign_background,
            educational_level,
            total_income,
            disposable_income,
            overcrowdedness
        ]


        for year in self.YEARS:
            for stadsdel in self.ADM_AREA_3_CODES:
                source = SOURCE
                wave = year
                gid = '{' + self.ADM_AREA_3_CODES.get(stadsdel) + '}'
                country = 'Sweden'
                countrycode = 'SWE'
                adm_area_1 = 'Skåne'
                adm_area_2 = 'Malmö'
                adm_area_3 = stadsdel
                # samplesize = None
                prop_dict = {}

                for i in data_dicts:
                    for key, value in i.items():
                        if value['year'] == year:
                            if value['district'] == stadsdel:
                                if i == total_income or i == disposable_income:
                                    prop_dict[value.get('indicator')] = {
                                        'number_of_people': int(value.get('number of people')),
                                        'average': int(value.get('average income'))
                                    }
                                    #prop_dict[value.get('indicator')] = value.get('number of people')
                                elif i == overcrowdedness:
                                    prop_dict[value.get('indicator')] = {
                                        'not_overcrowded': int(value.get('not overcrowded')),
                                        'overcrowded': int(value.get('overcrowded'))
                                    }
                                else:
                                    prop_dict[value.get('indicator')] = value.get('number')


                properties = json.dumps(prop_dict, ensure_ascii=False)
                
                # samplesize is excluded from this insert
                insert_query = f"INSERT INTO surveys (source, wave, gid, country, countrycode, adm_area_1, adm_area_2, adm_area_3, properties) VALUES ('{source}', '{wave}', '{gid}', '{country}', '{countrycode}', '{adm_area_1}', '{adm_area_2}', '{adm_area_3}', '{properties}');"
                sql_insert += f'\n{insert_query}'

        fname = os.path.join(BASE_PATH, 'SWE_SCB_malmo_demographics.sql')
        tf = open(fname, 'w')
        tf.write(sql_insert)
        tf.close()


if __name__ == '__main__':
    fetcher = MalmoDemographicsFetcher()
    fetcher.run()